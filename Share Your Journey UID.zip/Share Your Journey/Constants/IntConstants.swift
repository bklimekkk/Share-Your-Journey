//
//  Numeric.swift
//  Share Your Journey
//
//  Created by Bartosz Klimek on 01/01/2023.
//

import Foundation

struct IntConstants {
    static let defaultValue = 0
    static let routeWidth = 7
    static let initialMapVisibleMeters = 1000
}
