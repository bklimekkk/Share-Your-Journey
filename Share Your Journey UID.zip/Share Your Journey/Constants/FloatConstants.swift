//
//  FloatConstants.swift
//  Share Your Journey
//
//  Created by Bartosz Klimek on 01/01/2023.
//

import Foundation

struct FloatConstants {
    static let shortAnimationDuration = 0.15
}
