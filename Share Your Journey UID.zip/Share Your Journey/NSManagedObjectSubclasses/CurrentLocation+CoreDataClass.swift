//
//  CurrentLocation+CoreDataClass.swift
//  Share Your Journey
//
//  Created by Bartosz Klimek on 13/08/2022.
//
//

import Foundation
import CoreData

@objc(CurrentLocation)
public class CurrentLocation: NSManagedObject {

}
