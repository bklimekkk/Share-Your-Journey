//
//  Enums.swift
//  Share Your Journey
//
//  Created by Bartosz Klimek on 19/01/2023.
//

import Foundation

//Enum's cases control how users view journey's photos at the particular moment.
enum ViewType {
    case photoAlbum
    case threeDimensional
}
